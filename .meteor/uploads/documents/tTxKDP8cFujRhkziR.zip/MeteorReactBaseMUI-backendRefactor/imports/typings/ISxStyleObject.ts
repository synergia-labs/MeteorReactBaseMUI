import { SxProps } from '@mui/system';

export interface ISxStyleObject {
	[key: string]: SxProps;
}
