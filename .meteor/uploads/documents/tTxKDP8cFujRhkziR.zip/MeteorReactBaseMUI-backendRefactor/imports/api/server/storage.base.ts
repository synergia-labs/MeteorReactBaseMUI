export class StorageBase {}
