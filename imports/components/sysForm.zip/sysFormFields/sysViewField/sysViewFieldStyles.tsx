import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { sysSizes } from "../../../theme/sizes";

interface IInfo {
	type: "label" | "placeholder";
	disabled: boolean;
}

export const SysViewFieldStyle = {
	Container: styled(Box)(() => ({
		display: "flex",
		flexDirection: "column",
		gap: sysSizes.spacingFixed.xs
	})),

	Info: styled(Typography)<IInfo>(({ theme, type, disabled }) => ({
		display: "flex",
		alignItems: "center",
		color: disabled
			? theme.palette.sysText?.disabled
			: type == "label"
				? theme.palette.sysText?.auxiliary
				: theme.palette.sysText?.body
	}))
};
